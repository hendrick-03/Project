package ac.mz.projecto01;

import androidx.appcompat.app.AppCompatActivity;

import ac.mz.projecto01.databinding.ActivityCadastrosBinding;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Cadastros extends AppCompatActivity {

    DBConectionClass db;
    private ActivityCadastrosBinding cadastrosBinding;
   // EditText email_ed = findViewById(R.id.email_ED);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cadastrosBinding = ActivityCadastrosBinding.inflate(getLayoutInflater());
        View view = cadastrosBinding.getRoot();
        setContentView(view);

        db = new DBConectionClass(this);

        cadastrosBinding.CadastrarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nome = cadastrosBinding.nomeCad.getText().toString();
                //String email = email_ed.getText().toString();
                String senha = cadastrosBinding.senhaCad.getText().toString();
                String senha2 = cadastrosBinding.senhaCad02.getText().toString();


                if (nome.isEmpty() || senha.isEmpty() || senha2.isEmpty()) {
                    Toast.makeText(Cadastros.this, "Preencha todos os Campos", Toast.LENGTH_SHORT).show();

                } else {
                    if (senha.equalsIgnoreCase(senha2)) {
                      //  boolean checkuser = db.BuscaDados(nome);

                        if (!senha.isEmpty()) {
                            Boolean inserir = db.BuscarNome(nome, senha);
                            if (inserir == true) {
                                Toast.makeText(Cadastros.this, " Registrado com Sucesso", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(Cadastros.this, MainActivity.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(Cadastros.this, "Registro Falhou ", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Cadastros.this, "As Credenciais ja existem, pode fazer Login", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(Cadastros.this, "As Senhas nao coincidem", Toast.LENGTH_SHORT).show();

                    }
                }

            }


        });
        {


        }
    }
}