package ac.mz.projecto01;

import androidx.appcompat.app.AppCompatActivity;
import ac.mz.projecto01.databinding.ActivityMainBinding;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private ActivityMainBinding bidingMain;
    DBConectionClass db;
    private EditText nome_id,senha_id;



    CadrastosDePessoa pessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bidingMain = ActivityMainBinding.inflate(getLayoutInflater());
        View view = bidingMain.getRoot();
        setContentView(view);
        setContentView(R.layout.activity_main);

        nome_id = findViewById(R.id.nome_id);
        senha_id  = findViewById(R.id.senha_id);

        db = new DBConectionClass(this);


        bidingMain.proximoEd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Cadastros.class));

            }
        });

        Intent i = getIntent();
        pessoa = ((CadrastosDePessoa) i.getSerializableExtra(DBConectionClass.DATABASENAME));
        /*
        bidingMain.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bidingMain.nomeId == null || bidingMain.senhaEd == null){
                    Toast.makeText(getApplicationContext(), "Os campos precisam ser preenchidos", Toast.LENGTH_SHORT).show();

                }else{
                    DBConectionClass db = new DBConectionClass(getApplicationContext());
                     Cursor cursor = db.BuscaDados(new String[]{bidingMain.nomeId.getText().toString()});
                    if(cursor.getCount() != 0){
                        String pass = cursor.getString(2);
                         if(bidingMain.senhaEd.getText().toString().equals(pass)){
                             Intent i = new Intent(getApplicationContext(), MenuPrincipal.class);
                             i.putExtra(DBConectionClass.DATABASENAME,
                                     new CadrastosDePessoa(
                                             cursor.getString(0),
                                     cursor.getString(1),
                                             cursor.getString(2)));
                             startActivity(i);
                             db.close();
                             cursor.close();
                             return;

                         }Toast.makeText(getApplicationContext(),"O Seu emial ou senha nao existe !", Toast.LENGTH_SHORT).show();



                    }else {
                        Toast.makeText(getApplicationContext(),"O Seu emial ou senha nao existe !", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        /*

         */

        //setContentView(R.layout.activity_main);
        bidingMain.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               String nome = nome_id.getText().toString();
               String senha_001 = senha_id.getText().toString();




                if(nome.equals("") || senha_001.equals("")){
                    Toast.makeText(MainActivity.this, "Preencha todos campos", Toast.LENGTH_SHORT).show();

                }else{
                    Boolean checkuserpass = db.BuscarNome(nome,senha_001);

                    if(checkuserpass == true){
                        Toast.makeText(MainActivity.this, "Login com Sucesso", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), MenuPrincipal.class);
                        startActivity(i);

                    }else{
                        Toast.makeText(MainActivity.this, "Credencias Invalidas", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });
    }

    public void cadastrar(View view){
        startActivity(new Intent(MainActivity.this, Cadastros.class));
    }
}