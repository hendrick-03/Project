package ac.mz.projecto01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import ac.mz.projecto01.databinding.ActivityMainBinding;
import ac.mz.projecto01.ui.AddPessoa;
import ac.mz.projecto01.ui.HomeFragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

public class MenuPrincipal extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private ActivityMainBinding bidingMain;
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bidingMain = ActivityMainBinding.inflate(getLayoutInflater());
        View view = bidingMain.getRoot();
        setContentView(view);

        Toolbar toolbar = findViewById(R.id.myToolBar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navegationView = findViewById(R.id.nav_view);
        navegationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toogle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toogle);

        toogle.syncState();
        if(savedInstanceState ==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.nav_home,
                new HomeFragment()).commit();
            navegationView.setCheckedItem(R.id.nav_home);
        }

    }

    public void onBackPress() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.nav_home,
                        new HomeFragment()).commit();
                break;
            case R.id.add_itm:
                getSupportFragmentManager().beginTransaction().replace(R.id.nav_home,
                        new AddPessoa()).commit();
                break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}