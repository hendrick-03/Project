package ac.mz.projecto01;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBConectionClass extends SQLiteOpenHelper {
    public static final String DATABASENAME = "Gym.db";
    private static final String CADASTRO = "CadastroGym";
    private static final String NOME = "Nome";
    //private static  final String EMAIL = "Email";
    private static final String PASSWORD = "Password";
    //private static final String GENERO = "Genero";

    public DBConectionClass(@Nullable Context context) {

        super(context,DATABASENAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = " CREATE TABLE " + CADASTRO + "(" +
                NOME + "TEXT NOT NULL, " +
                //EMAIL + "TEXT NOT NULL, " +
                //GENERO + "TEXT NOT NULL, " +
                PASSWORD + "TEXT NOT NULL)";

        db.execSQL(sql);

       // db.execSQL("create Table users(username TEXT primary key, password TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = " DROP  TABLE IF EXISTS " + CADASTRO ;

        db.execSQL(sql);



        //db.execSQL("drop table if exists users");

    }
         //"Vinha"long
    public boolean dados(String nome,String email ,String password, String genero){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(NOME, nome);
       // cv.put(EMAIL, nome);
       // cv.put(GENERO, genero);
        cv.put(PASSWORD, password);

        long result = db.insert("CADASTRO",null, cv);
         //return db.insert(CADASTRO, null, cv);
        if(result ==-1){
            return false;

        }else{
            return true;
        }


    }
    public boolean BuscaDados(String nome){
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from CadastroGym where Nome like '" + nome + "' ",  new String[] {String.valueOf(nome)});

       // String sql = " SELECT * FROM " + CADASTRO + " WHERE "+ NOME + " = ? ";

        //return db.rawQuery(sql,nome);
        if(cursor.getCount()> 0){
            return true;

        }else {
            return false;
        }

    }
    public boolean BuscarNome(String nome, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from users where username = ? and password = ?", new String[]{nome, password});

        if(cursor.getCount()>0){
            return true;


        }else {
            return false;
        }

    }


}
