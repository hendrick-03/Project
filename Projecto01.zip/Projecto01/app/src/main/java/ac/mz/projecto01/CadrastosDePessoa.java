package ac.mz.projecto01;

import java.io.Serializable;

public class CadrastosDePessoa implements Serializable {

    private String nome;
    private String senha;
    private String genero;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public CadrastosDePessoa(String nome, String senha, String genero) {
        this.nome = nome;
        this.senha = senha;
        this.genero = genero;
    }
}
